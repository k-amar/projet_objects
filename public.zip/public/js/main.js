$(document).ready(function(){
  $('.delete-object').on('click', function(e){
    $target = $(e.target);
    const id = $target.attr('data-id');
    $.ajax({
      type:'DELETE',
      url: '/objects/'+id,
      success: function(response){
        alert('Deleting Object');
        window.location.href='/';
      },
      error: function(err){
        console.log(err);
      }
    });
  });
});
